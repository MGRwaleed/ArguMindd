
/** @type {import('tailwindcss').Config} */
export default {
  content: [
  './index.html',
  './src/**/*.{js,ts,jsx,tsx}'
],
  theme: {
    extend: {
      colors: {
        debate: {
          bg: '#0B0F19',
          surface: '#111827',
          'surface-light': '#1a2235',
          primary: '#22D3EE',
          accent: '#F97316',
          'text-primary': '#E5E7EB',
          'text-secondary': '#9CA3AF',
          border: '#1f2937',
          'border-light': '#374151',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', '-apple-system', 'sans-serif'],
      },
      boxShadow: {
        'cyan-glow': '0 0 20px rgba(34, 211, 238, 0.15), 0 0 40px rgba(34, 211, 238, 0.05)',
        'cyan-glow-strong': '0 0 24px rgba(34, 211, 238, 0.25), 0 0 48px rgba(34, 211, 238, 0.1)',
        'orange-glow': '0 0 20px rgba(249, 115, 22, 0.15)',
        'surface': '0 1px 3px rgba(0, 0, 0, 0.3), 0 1px 2px rgba(0, 0, 0, 0.2)',
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
      },
    },
  },
  plugins: [],
}
