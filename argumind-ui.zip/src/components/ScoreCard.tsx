import React from 'react';
import { TrophyIcon, CrownIcon } from 'lucide-react';
interface RoundScore {
  round: number;
  speaker1: number;
  speaker2: number;
}
interface ScoreCardProps {
  speaker1Name: string;
  speaker2Name: string;
  roundScores: RoundScore[];
  winnerId?: number;
}
export function ScoreCard({
  speaker1Name,
  speaker2Name,
  roundScores,
  winnerId
}: ScoreCardProps) {
  const totalS1 = roundScores.reduce((sum, r) => sum + r.speaker1, 0);
  const totalS2 = roundScores.reduce((sum, r) => sum + r.speaker2, 0);
  const maxPossiblePerRound = 10;
  const maxTotal = roundScores.length * maxPossiblePerRound;
  return (
    <div
      className={`
      rounded-xl border bg-debate-surface overflow-hidden transition-all duration-500
      ${winnerId !== undefined ? winnerId === 0 ? 'border-debate-primary/30' : 'border-purple-500/30' : 'border-debate-border'}
    `}>
      
      {/* Header */}
      <div className="px-4 py-3 border-b border-debate-border flex items-center justify-between">
        <h3 className="text-xs font-semibold uppercase tracking-wider text-debate-text-secondary">
          Scores
        </h3>
        {winnerId !== undefined &&
        <div
          className={`flex items-center gap-1.5 ${winnerId === 0 ? 'text-debate-primary' : 'text-purple-400'}`}>
          
            <TrophyIcon className="w-3.5 h-3.5" />
            <span className="text-[10px] font-semibold uppercase tracking-wider">
              {winnerId === 0 ? speaker1Name : speaker2Name} leads
            </span>
          </div>
        }
      </div>

      {/* Score table */}
      <div className="p-4">
        {/* Column headers */}
        <div className="grid grid-cols-[1fr_auto_auto] gap-2 mb-3 text-[10px] font-semibold uppercase tracking-wider text-debate-text-secondary">
          <span>Round</span>
          <span className="w-16 text-center text-debate-primary">
            {speaker1Name.split(' ')[0]}
          </span>
          <span className="w-16 text-center text-purple-400">
            {speaker2Name.split(' ')[0]}
          </span>
        </div>

        {/* Round rows with progress bars */}
        <div className="space-y-2">
          {roundScores.map((rs) => {
            const s1Wins = rs.speaker1 > rs.speaker2;
            const s2Wins = rs.speaker2 > rs.speaker1;
            const s1Pct = rs.speaker1 / maxPossiblePerRound * 100;
            const s2Pct = rs.speaker2 / maxPossiblePerRound * 100;
            return (
              <div
                key={rs.round}
                className="py-2 px-2.5 rounded-lg bg-debate-bg/50">
                
                <div className="grid grid-cols-[1fr_auto_auto] gap-2 items-center mb-1.5">
                  <span className="text-xs text-debate-text-secondary font-medium">
                    R{rs.round}
                  </span>
                  <span
                    className={`w-16 text-center text-sm font-semibold tabular-nums ${s1Wins ? 'text-debate-primary' : 'text-debate-text-secondary'}`}>
                    
                    {rs.speaker1}
                  </span>
                  <span
                    className={`w-16 text-center text-sm font-semibold tabular-nums ${s2Wins ? 'text-purple-400' : 'text-debate-text-secondary'}`}>
                    
                    {rs.speaker2}
                  </span>
                </div>
                {/* Progress bars */}
                <div className="grid grid-cols-[1fr_auto_auto] gap-2 items-center">
                  <div />
                  <div className="w-16 flex justify-center">
                    <div className="w-12 h-1 bg-debate-border rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full animate-score-fill ${s1Wins ? 'bg-debate-primary' : 'bg-debate-primary/40'}`}
                        style={{
                          width: `${s1Pct}%`
                        }} />
                      
                    </div>
                  </div>
                  <div className="w-16 flex justify-center">
                    <div className="w-12 h-1 bg-debate-border rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full animate-score-fill ${s2Wins ? 'bg-purple-400' : 'bg-purple-400/40'}`}
                        style={{
                          width: `${s2Pct}%`
                        }} />
                      
                    </div>
                  </div>
                </div>
              </div>);

          })}
        </div>

        {/* Totals with larger progress bars */}
        <div className="mt-3 pt-3 border-t border-debate-border">
          <div className="grid grid-cols-[1fr_auto_auto] gap-2 items-center mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-debate-text-primary">
              Total
            </span>
            <span
              className={`w-16 text-center text-base font-bold tabular-nums transition-all duration-500 ${winnerId === 0 ? 'text-debate-primary' : 'text-debate-text-primary'}`}>
              
              {totalS1}
            </span>
            <span
              className={`w-16 text-center text-base font-bold tabular-nums transition-all duration-500 ${winnerId === 1 ? 'text-purple-400' : 'text-debate-text-primary'}`}>
              
              {totalS2}
            </span>
          </div>
          {/* Total progress bars */}
          <div className="grid grid-cols-[1fr_auto_auto] gap-2 items-center">
            <div />
            <div className="w-16 flex justify-center">
              <div className="w-12 h-1.5 bg-debate-border rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full animate-score-fill ${winnerId === 0 ? 'bg-debate-primary' : 'bg-debate-primary/50'}`}
                  style={{
                    width: `${maxTotal > 0 ? totalS1 / maxTotal * 100 : 0}%`
                  }} />
                
              </div>
            </div>
            <div className="w-16 flex justify-center">
              <div className="w-12 h-1.5 bg-debate-border rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full animate-score-fill ${winnerId === 1 ? 'bg-purple-400' : 'bg-purple-400/50'}`}
                  style={{
                    width: `${maxTotal > 0 ? totalS2 / maxTotal * 100 : 0}%`
                  }} />
                
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Winner banner with glow */}
      {winnerId !== undefined &&
      <div
        className={`
            px-4 py-3 text-center text-xs font-semibold uppercase tracking-wider flex items-center justify-center gap-2
            ${winnerId === 0 ? 'bg-debate-primary/10 text-debate-primary border-t border-debate-primary/20' : 'bg-purple-500/10 text-purple-400 border-t border-purple-500/20'}
          `}>
        
          <CrownIcon className="w-3.5 h-3.5" />
          {winnerId === 0 ? speaker1Name : speaker2Name} is winning
        </div>
      }
    </div>);

}
export type { RoundScore, ScoreCardProps };