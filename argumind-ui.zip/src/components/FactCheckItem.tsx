import React, { useState } from 'react';
import {
  CheckCircle2Icon,
  XCircleIcon,
  HelpCircleIcon,
  ChevronDownIcon } from
'lucide-react';
type Verdict = 'true' | 'false' | 'uncertain';
interface FactCheckItemProps {
  claim: string;
  verdict: Verdict;
  evidence: string;
  source?: string;
  speaker: string;
  speakerIndex: number;
}
const verdictConfig: Record<
  Verdict,
  {
    label: string;
    icon: React.ElementType;
    colorClass: string;
    bgClass: string;
    borderClass: string;
    leftBorderClass: string;
  }> =
{
  true: {
    label: 'Verified',
    icon: CheckCircle2Icon,
    colorClass: 'text-emerald-400',
    bgClass: 'bg-emerald-400/10',
    borderClass: 'border-emerald-400/20',
    leftBorderClass: 'border-l-emerald-400/70'
  },
  false: {
    label: 'False',
    icon: XCircleIcon,
    colorClass: 'text-debate-accent',
    bgClass: 'bg-debate-accent/10',
    borderClass: 'border-debate-accent/20',
    leftBorderClass: 'border-l-debate-accent/70'
  },
  uncertain: {
    label: 'Uncertain',
    icon: HelpCircleIcon,
    colorClass: 'text-debate-text-secondary',
    bgClass: 'bg-debate-text-secondary/10',
    borderClass: 'border-debate-text-secondary/20',
    leftBorderClass: 'border-l-debate-text-secondary/40'
  }
};
export function FactCheckItem({
  claim,
  verdict,
  evidence,
  source,
  speaker,
  speakerIndex
}: FactCheckItemProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const config = verdictConfig[verdict];
  const VerdictIcon = config.icon;
  return (
    <div
      className={`
        rounded-xl border border-l-[3px] transition-all duration-200
        ${config.borderClass} ${config.leftBorderClass} bg-debate-surface
      `}>
      
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full text-left p-4 flex items-start gap-3 cursor-pointer"
        aria-expanded={isExpanded}>
        
        <div
          className={`
          w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5
          ${config.bgClass}
        `}>
          
          <VerdictIcon className={`w-4 h-4 ${config.colorClass}`} />
        </div>

        <div className="flex-1 min-w-0">
          <p className="text-sm text-debate-text-primary leading-snug line-clamp-2">
            &ldquo;{claim}&rdquo;
          </p>
          <div className="flex items-center gap-2 mt-2">
            <span
              className={`
                inline-flex items-center gap-1 text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-md
                ${config.bgClass} ${config.colorClass}
              `}>
              
              <VerdictIcon className="w-3 h-3" />
              {config.label}
            </span>
            <span className="text-[10px] text-debate-text-secondary">
              — {speaker}
            </span>
          </div>
        </div>

        <ChevronDownIcon
          className={`w-4 h-4 text-debate-text-secondary flex-shrink-0 mt-1 transition-transform duration-200 ${isExpanded ? 'rotate-180' : ''}`} />
        
      </button>

      {isExpanded &&
      <div className="px-4 pb-4 pt-0 ml-10">
          <div className="border-t border-debate-border pt-3 space-y-2">
            <p className="text-xs text-debate-text-secondary leading-relaxed">
              {evidence}
            </p>
            {source &&
          <p className="text-[10px] text-debate-text-secondary/60 italic flex items-center gap-1">
                <span className="w-1 h-1 rounded-full bg-debate-text-secondary/30" />
                Source: {source}
              </p>
          }
          </div>
        </div>
      }
    </div>);

}
export type { Verdict, FactCheckItemProps };