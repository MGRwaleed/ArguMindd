import React from 'react';
import {
  MicIcon,
  MicOffIcon,
  VideoIcon,
  VideoOffIcon,
  UserIcon } from
'lucide-react';
interface VideoCardProps {
  name: string;
  role: string;
  avatar: string;
  speakerIndex: number;
  isActive: boolean;
  isMuted?: boolean;
  isCameraOff?: boolean;
  score: number;
}
export function VideoCard({
  name,
  role,
  avatar,
  speakerIndex,
  isActive,
  isMuted = false,
  isCameraOff = false,
  score
}: VideoCardProps) {
  return (
    <div
      className={`
        relative flex-1 rounded-xl overflow-hidden border transition-all duration-500
        ${isActive ? speakerIndex === 0 ? 'border-debate-primary/50 video-glow-cyan' : 'border-purple-400/50 video-glow-purple' : 'border-debate-border opacity-60'}
      `}>
      
      {/* Video placeholder — dark gradient with silhouette */}
      <div
        className={`
        relative w-full aspect-[16/9] bg-gradient-to-br from-debate-surface via-debate-bg to-debate-surface
        transition-all duration-500
        ${!isActive ? 'brightness-75' : ''}
      `}>
        
        {/* Subtle grid pattern overlay */}
        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage:
            'radial-gradient(circle, #E5E7EB 1px, transparent 1px)',
            backgroundSize: '20px 20px'
          }} />
        

        {/* Center avatar / silhouette */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div
            className={`
              w-16 h-16 rounded-full flex items-center justify-center transition-all duration-500
              ${isActive ? speakerIndex === 0 ? 'bg-debate-primary/15 border-2 border-debate-primary/30 scale-105' : 'bg-purple-500/15 border-2 border-purple-500/30 scale-105' : speakerIndex === 0 ? 'bg-debate-primary/10 border border-debate-primary/15' : 'bg-purple-500/10 border border-purple-500/15'}
            `}>
            
            <UserIcon
              className={`w-8 h-8 transition-colors duration-500 ${isActive ? speakerIndex === 0 ? 'text-debate-primary/60' : 'text-purple-400/60' : speakerIndex === 0 ? 'text-debate-primary/25' : 'text-purple-400/25'}`} />
            
          </div>
        </div>

        {/* Audio waveform visualization when active */}
        {isActive &&
        <div className="absolute bottom-12 left-1/2 -translate-x-1/2 flex items-end gap-[3px] h-6">
            {[0.4, 0.7, 1, 0.8, 0.5, 0.9, 0.6, 0.3, 0.7, 0.5, 0.8, 0.4].map(
            (h, i) =>
            <div
              key={i}
              className={`w-[3px] rounded-full ${speakerIndex === 0 ? 'bg-debate-primary/60' : 'bg-purple-400/60'}`}
              style={{
                height: `${h * 100}%`,
                animation: `waveform 1.2s ease-in-out ${i * 0.1}s infinite alternate`
              }} />


          )}
          </div>
        }

        {/* Top-left: LIVE indicator */}
        <div className="absolute top-3 left-3 flex items-center gap-1.5">
          <div className="flex items-center gap-1.5 px-2 py-1 rounded-md bg-black/50 backdrop-blur-sm">
            <div
              className={`w-1.5 h-1.5 rounded-full ${isActive ? 'bg-red-500 animate-pulse' : 'bg-debate-text-secondary/40'}`} />
            
            <span
              className={`text-[10px] font-semibold uppercase tracking-wider ${isActive ? 'text-white' : 'text-debate-text-secondary/50'}`}>
              
              Live
            </span>
          </div>
        </div>

        {/* Top-right: Score badge */}
        <div className="absolute top-3 right-3">
          <div
            className={`
              px-2.5 py-1 rounded-md backdrop-blur-sm text-xs font-bold tabular-nums transition-all duration-500
              ${isActive ? speakerIndex === 0 ? 'bg-debate-primary/20 text-debate-primary border border-debate-primary/30' : 'bg-purple-500/20 text-purple-400 border border-purple-500/30' : speakerIndex === 0 ? 'bg-debate-primary/10 text-debate-primary/60 border border-debate-primary/10' : 'bg-purple-500/10 text-purple-400/60 border border-purple-500/10'}
            `}>
            
            {score}
          </div>
        </div>

        {/* Bottom overlay — speaker info + controls */}
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 via-black/40 to-transparent px-3.5 pb-3 pt-8">
          <div className="flex items-end justify-between">
            {/* Speaker info */}
            <div className="min-w-0">
              <div className="flex items-center gap-2 mb-0.5">
                <p
                  className={`text-sm font-semibold truncate transition-colors duration-300 ${isActive ? 'text-white' : 'text-white/60'}`}>
                  
                  {name}
                </p>
                {isActive &&
                <span
                  className={`
                      inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider
                      ${speakerIndex === 0 ? 'bg-debate-primary/25 text-debate-primary' : 'bg-purple-500/25 text-purple-400'}
                    `}>
                  
                    <span className="w-1 h-1 rounded-full bg-current animate-pulse" />
                    Speaking
                  </span>
                }
              </div>
              <p
                className={`text-[11px] transition-colors duration-300 ${isActive ? 'text-white/50' : 'text-white/30'}`}>
                
                {role}
              </p>
            </div>

            {/* Controls */}
            <div className="flex items-center gap-1.5 flex-shrink-0 ml-2">
              <div
                className={`
                  w-7 h-7 rounded-lg flex items-center justify-center backdrop-blur-sm transition-colors
                  ${isMuted ? 'bg-red-500/20 text-red-400' : 'bg-white/10 text-white/70'}
                `}>
                
                {isMuted ?
                <MicOffIcon className="w-3.5 h-3.5" /> :

                <MicIcon className="w-3.5 h-3.5" />
                }
              </div>
              <div
                className={`
                  w-7 h-7 rounded-lg flex items-center justify-center backdrop-blur-sm transition-colors
                  ${isCameraOff ? 'bg-red-500/20 text-red-400' : 'bg-white/10 text-white/70'}
                `}>
                
                {isCameraOff ?
                <VideoOffIcon className="w-3.5 h-3.5" /> :

                <VideoIcon className="w-3.5 h-3.5" />
                }
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>);

}