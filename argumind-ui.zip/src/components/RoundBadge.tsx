import React from 'react';
interface RoundBadgeProps {
  round: number;
  isActive?: boolean;
  size?: 'sm' | 'md';
}
export function RoundBadge({
  round,
  isActive = false,
  size = 'sm'
}: RoundBadgeProps) {
  const sizeClasses =
  size === 'sm' ? 'text-[10px] px-2 py-0.5' : 'text-xs px-2.5 py-1';
  return (
    <span
      className={`
        inline-flex items-center font-semibold tracking-wider uppercase rounded-md
        ${sizeClasses}
        ${isActive ? 'bg-debate-primary/15 text-debate-primary border border-debate-primary/30' : 'bg-debate-surface-light text-debate-text-secondary border border-debate-border'}
      `}>
      
      R{round}
    </span>);

}