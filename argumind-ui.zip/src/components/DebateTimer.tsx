import React, { useCallback, useEffect, useState } from 'react';
import { ClockIcon } from 'lucide-react';
interface DebateTimerProps {
  totalSeconds: number;
  isRunning: boolean;
  onTimeUp?: () => void;
}
export function DebateTimer({
  totalSeconds,
  isRunning,
  onTimeUp
}: DebateTimerProps) {
  const [remaining, setRemaining] = useState(totalSeconds);
  useEffect(() => {
    setRemaining(totalSeconds);
  }, [totalSeconds]);
  useEffect(() => {
    if (!isRunning || remaining <= 0) return;
    const interval = setInterval(() => {
      setRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          onTimeUp?.();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [isRunning, remaining, onTimeUp]);
  const minutes = Math.floor(remaining / 60);
  const seconds = remaining % 60;
  const isWarning = remaining <= 10 && remaining > 0;
  const isExpired = remaining === 0;
  const progress = totalSeconds > 0 ? remaining / totalSeconds : 0;
  return (
    <div
      className={`
        flex items-center gap-2.5 px-4 py-2.5 rounded-xl border transition-all duration-500
        ${isWarning ? 'bg-debate-accent/10 border-debate-accent/40 shadow-orange-glow' : isExpired ? 'bg-red-500/10 border-red-500/30' : 'bg-debate-surface border-debate-border'}
      `}>
      
      <ClockIcon
        className={`w-4 h-4 transition-colors duration-500 ${isWarning ? 'text-debate-accent' : isExpired ? 'text-red-400' : 'text-debate-text-secondary'}`} />
      
      <span
        className={`
          font-mono text-lg font-semibold tracking-wider tabular-nums transition-colors duration-500
          ${isWarning ? 'text-debate-accent' : isExpired ? 'text-red-400' : 'text-debate-text-primary'}
        `}>
        
        {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
      </span>
      {/* Progress bar */}
      <div className="w-16 h-1 bg-debate-border rounded-full overflow-hidden ml-1">
        <div
          className={`h-full rounded-full transition-all duration-1000 ease-linear ${isWarning ? 'bg-debate-accent' : isExpired ? 'bg-red-400' : 'bg-debate-primary/60'}`}
          style={{
            width: `${progress * 100}%`
          }} />
        
      </div>
    </div>);

}