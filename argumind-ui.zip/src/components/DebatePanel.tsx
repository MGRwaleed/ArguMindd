import React from 'react';
import { SpeakerCard } from './SpeakerCard';
import { DebateTimer } from './DebateTimer';
import { RoundBadge } from './RoundBadge';
import { ZapIcon } from 'lucide-react';
interface Speaker {
  name: string;
  role: string;
  avatar: string;
}
interface DebatePanelProps {
  speakers: [Speaker, Speaker];
  activeSpeaker: number;
  currentRound: number;
  totalRounds: number;
  timerSeconds: number;
  isTimerRunning: boolean;
  topic: string;
}
export function DebatePanel({
  speakers,
  activeSpeaker,
  currentRound,
  totalRounds,
  timerSeconds,
  isTimerRunning,
  topic
}: DebatePanelProps) {
  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="px-5 py-4 border-b border-debate-border">
        <div className="flex items-center gap-2 mb-3">
          <ZapIcon className="w-4 h-4 text-debate-primary" />
          <h2 className="text-xs font-semibold uppercase tracking-wider text-debate-text-secondary">
            Debate Room
          </h2>
        </div>
        <p className="text-sm font-medium text-debate-text-primary leading-snug">
          {topic}
        </p>
      </div>

      {/* Round & Timer */}
      <div className="px-5 py-4 border-b border-debate-border">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            {Array.from(
              {
                length: totalRounds
              },
              (_, i) =>
              <RoundBadge
                key={i}
                round={i + 1}
                isActive={currentRound === i + 1} />


            )}
          </div>
          <span className="text-[10px] text-debate-text-secondary font-medium">
            {currentRound} of {totalRounds}
          </span>
        </div>
        <DebateTimer totalSeconds={timerSeconds} isRunning={isTimerRunning} />
      </div>

      {/* Speakers */}
      <div className="px-5 py-4 flex-1">
        <h3 className="text-[10px] font-semibold uppercase tracking-wider text-debate-text-secondary mb-3">
          Speakers
        </h3>
        <div className="space-y-3">
          <SpeakerCard
            name={speakers[0].name}
            role={speakers[0].role}
            avatar={speakers[0].avatar}
            isActive={activeSpeaker === 0}
            speakerIndex={0} />
          
          <div className="flex items-center gap-3 px-2">
            <div className="flex-1 h-px bg-debate-border" />
            <span className="text-[10px] text-debate-text-secondary font-medium uppercase tracking-wider">
              vs
            </span>
            <div className="flex-1 h-px bg-debate-border" />
          </div>
          <SpeakerCard
            name={speakers[1].name}
            role={speakers[1].role}
            avatar={speakers[1].avatar}
            isActive={activeSpeaker === 1}
            speakerIndex={1} />
          
        </div>
      </div>

      {/* Status */}
      <div className="px-5 py-3 border-t border-debate-border">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse-slow" />
          <span className="text-[10px] text-debate-text-secondary font-medium">
            Live — AI Analysis Active
          </span>
        </div>
      </div>
    </div>);

}
export type { Speaker };