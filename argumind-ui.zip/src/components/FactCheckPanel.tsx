import React from 'react';
import { FactCheckItem } from './FactCheckItem';
import { ScoreCard } from './ScoreCard';
import { RoundBadge } from './RoundBadge';
import { ShieldCheckIcon, FileTextIcon } from 'lucide-react';
import type { Verdict } from './FactCheckItem';
import type { RoundScore } from './ScoreCard';
interface FactCheck {
  id: string;
  round: number;
  claim: string;
  verdict: Verdict;
  evidence: string;
  source?: string;
  speaker: string;
  speakerIndex: number;
}
interface FactCheckPanelProps {
  factChecks: FactCheck[];
  roundScores: RoundScore[];
  speaker1Name: string;
  speaker2Name: string;
  winnerId?: number;
  currentRound: number;
  onOpenSummary: () => void;
}
export function FactCheckPanel({
  factChecks,
  roundScores,
  speaker1Name,
  speaker2Name,
  winnerId,
  currentRound,
  onOpenSummary
}: FactCheckPanelProps) {
  // Group fact checks by round
  const roundGroups: Record<number, FactCheck[]> = {};
  factChecks.forEach((fc) => {
    if (!roundGroups[fc.round]) roundGroups[fc.round] = [];
    roundGroups[fc.round].push(fc);
  });
  const sortedRounds = Object.keys(roundGroups).
  map(Number).
  sort((a, b) => a - b);
  const trueCount = factChecks.filter((fc) => fc.verdict === 'true').length;
  const falseCount = factChecks.filter((fc) => fc.verdict === 'false').length;
  const uncertainCount = factChecks.filter(
    (fc) => fc.verdict === 'uncertain'
  ).length;
  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="px-5 py-4 border-b border-debate-border flex-shrink-0">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <ShieldCheckIcon className="w-4 h-4 text-debate-primary" />
            <h2 className="text-xs font-semibold uppercase tracking-wider text-debate-text-secondary">
              Fact Check
            </h2>
          </div>
          <button
            onClick={onOpenSummary}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-[10px] font-semibold uppercase tracking-wider text-debate-primary bg-debate-primary/10 border border-debate-primary/20 hover:bg-debate-primary/15 transition-colors cursor-pointer">
            
            <FileTextIcon className="w-3 h-3" />
            Summary
          </button>
        </div>

        {/* Stats bar */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full bg-emerald-400" />
            <span className="text-[10px] text-debate-text-secondary font-medium">
              {trueCount} Verified
            </span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full bg-debate-accent" />
            <span className="text-[10px] text-debate-text-secondary font-medium">
              {falseCount} False
            </span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full bg-debate-text-secondary" />
            <span className="text-[10px] text-debate-text-secondary font-medium">
              {uncertainCount} Uncertain
            </span>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-5 py-4 space-y-5">
        {/* Scores */}
        <ScoreCard
          speaker1Name={speaker1Name}
          speaker2Name={speaker2Name}
          roundScores={roundScores}
          winnerId={winnerId} />
        

        {/* Fact checks by round */}
        {sortedRounds.map((round) => {
          const checks = roundGroups[round];
          return (
            <div key={round}>
              <div className="flex items-center gap-3 mb-3">
                <RoundBadge
                  round={round}
                  isActive={round === currentRound}
                  size="md" />
                
                <div className="flex-1 h-px bg-debate-border" />
                <span className="text-[10px] text-debate-text-secondary">
                  {checks.length} claim{checks.length !== 1 ? 's' : ''}
                </span>
              </div>
              <div className="space-y-2.5">
                {checks.map((fc) =>
                <FactCheckItem
                  key={fc.id}
                  claim={fc.claim}
                  verdict={fc.verdict}
                  evidence={fc.evidence}
                  source={fc.source}
                  speaker={fc.speaker}
                  speakerIndex={fc.speakerIndex} />

                )}
              </div>
            </div>);

        })}
      </div>
    </div>);

}
export type { FactCheck };