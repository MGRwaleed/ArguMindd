import React from 'react';
import {
  XIcon,
  SparklesIcon,
  ShieldCheckIcon,
  AlertTriangleIcon,
  TrendingUpIcon } from
'lucide-react';
interface SummaryData {
  keyArguments: string[];
  speaker1Strengths: string[];
  speaker1Weaknesses: string[];
  speaker2Strengths: string[];
  speaker2Weaknesses: string[];
  overallVerdict: string;
}
interface DebateSummaryProps {
  isOpen: boolean;
  onClose: () => void;
  summary: SummaryData;
  speaker1Name: string;
  speaker2Name: string;
}
export function DebateSummary({
  isOpen,
  onClose,
  summary,
  speaker1Name,
  speaker2Name
}: DebateSummaryProps) {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
        onClick={onClose}
        aria-hidden="true" />
      

      {/* Modal */}
      <div className="relative w-full max-w-2xl max-h-[85vh] overflow-y-auto bg-debate-surface border border-debate-border rounded-2xl shadow-2xl">
        {/* Header */}
        <div className="sticky top-0 z-10 bg-debate-surface/95 backdrop-blur-sm px-6 py-4 border-b border-debate-border flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <SparklesIcon className="w-5 h-5 text-debate-primary" />
            <h2 className="text-lg font-bold text-debate-text-primary">
              Debate Summary
            </h2>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg flex items-center justify-center text-debate-text-secondary hover:text-debate-text-primary hover:bg-white/5 transition-colors cursor-pointer"
            aria-label="Close summary">
            
            <XIcon className="w-4 h-4" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* Overall Verdict */}
          <div className="p-4 rounded-xl bg-debate-primary/[0.06] border border-debate-primary/20">
            <p className="text-sm text-debate-text-primary leading-relaxed">
              {summary.overallVerdict}
            </p>
          </div>

          {/* Key Arguments */}
          <section>
            <div className="flex items-center gap-2 mb-3">
              <TrendingUpIcon className="w-4 h-4 text-debate-primary" />
              <h3 className="text-sm font-semibold text-debate-text-primary uppercase tracking-wider">
                Key Arguments
              </h3>
            </div>
            <ul className="space-y-2">
              {summary.keyArguments.map((arg, i) =>
              <li
                key={i}
                className="flex items-start gap-2.5 text-sm text-debate-text-secondary">
                
                  <span className="w-1.5 h-1.5 rounded-full bg-debate-primary mt-2 flex-shrink-0" />
                  {arg}
                </li>
              )}
            </ul>
          </section>

          {/* Speaker Analysis */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Speaker 1 */}
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-debate-primary">
                {speaker1Name}
              </h3>
              <div>
                <div className="flex items-center gap-1.5 mb-2">
                  <ShieldCheckIcon className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-[10px] font-semibold uppercase tracking-wider text-emerald-400">
                    Strengths
                  </span>
                </div>
                <ul className="space-y-1.5">
                  {summary.speaker1Strengths.map((s, i) =>
                  <li
                    key={i}
                    className="text-xs text-debate-text-secondary flex items-start gap-2">
                    
                      <span className="text-emerald-400 mt-0.5">+</span> {s}
                    </li>
                  )}
                </ul>
              </div>
              <div>
                <div className="flex items-center gap-1.5 mb-2">
                  <AlertTriangleIcon className="w-3.5 h-3.5 text-debate-accent" />
                  <span className="text-[10px] font-semibold uppercase tracking-wider text-debate-accent">
                    Weaknesses
                  </span>
                </div>
                <ul className="space-y-1.5">
                  {summary.speaker1Weaknesses.map((w, i) =>
                  <li
                    key={i}
                    className="text-xs text-debate-text-secondary flex items-start gap-2">
                    
                      <span className="text-debate-accent mt-0.5">−</span> {w}
                    </li>
                  )}
                </ul>
              </div>
            </div>

            {/* Speaker 2 */}
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-purple-400">
                {speaker2Name}
              </h3>
              <div>
                <div className="flex items-center gap-1.5 mb-2">
                  <ShieldCheckIcon className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-[10px] font-semibold uppercase tracking-wider text-emerald-400">
                    Strengths
                  </span>
                </div>
                <ul className="space-y-1.5">
                  {summary.speaker2Strengths.map((s, i) =>
                  <li
                    key={i}
                    className="text-xs text-debate-text-secondary flex items-start gap-2">
                    
                      <span className="text-emerald-400 mt-0.5">+</span> {s}
                    </li>
                  )}
                </ul>
              </div>
              <div>
                <div className="flex items-center gap-1.5 mb-2">
                  <AlertTriangleIcon className="w-3.5 h-3.5 text-debate-accent" />
                  <span className="text-[10px] font-semibold uppercase tracking-wider text-debate-accent">
                    Weaknesses
                  </span>
                </div>
                <ul className="space-y-1.5">
                  {summary.speaker2Weaknesses.map((w, i) =>
                  <li
                    key={i}
                    className="text-xs text-debate-text-secondary flex items-start gap-2">
                    
                      <span className="text-debate-accent mt-0.5">−</span> {w}
                    </li>
                  )}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>);

}
export type { SummaryData };