import React from 'react';
import { RoundBadge } from './RoundBadge';
interface TranscriptHighlight {
  type: 'keyword' | 'claim-false';
  start: number;
  end: number;
}
interface TranscriptEntry {
  id: string;
  speaker: string;
  speakerIndex: number;
  text: string;
  timestamp: string;
  round: number;
  highlights?: TranscriptHighlight[];
}
interface TranscriptBlockProps {
  entry: TranscriptEntry;
  showRoundLabel?: boolean;
  isLatest?: boolean;
  activeSpeaker?: number;
}
function renderHighlightedText(
text: string,
highlights?: TranscriptHighlight[])
{
  if (!highlights || highlights.length === 0) {
    return <span>{text}</span>;
  }
  const sorted = [...highlights].sort((a, b) => a.start - b.start);
  const parts: React.ReactNode[] = [];
  let lastIndex = 0;
  sorted.forEach((h, i) => {
    if (h.start > lastIndex) {
      parts.push(<span key={`t-${i}`}>{text.slice(lastIndex, h.start)}</span>);
    }
    const highlighted = text.slice(h.start, h.end);
    if (h.type === 'keyword') {
      parts.push(
        <span key={`h-${i}`} className="text-debate-primary/90 font-medium">
          {highlighted}
        </span>
      );
    } else if (h.type === 'claim-false') {
      parts.push(
        <span
          key={`h-${i}`}
          className="underline decoration-debate-accent/60 decoration-wavy underline-offset-2 text-debate-accent/80">
          
          {highlighted}
        </span>
      );
    }
    lastIndex = h.end;
  });
  if (lastIndex < text.length) {
    parts.push(<span key="rest">{text.slice(lastIndex)}</span>);
  }
  return <>{parts}</>;
}
export function TranscriptBlock({
  entry,
  showRoundLabel = false,
  isLatest = false,
  activeSpeaker
}: TranscriptBlockProps) {
  const isSpeaking =
  activeSpeaker !== undefined && entry.speakerIndex === activeSpeaker;
  const isDimmed =
  activeSpeaker !== undefined && entry.speakerIndex !== activeSpeaker;
  return (
    <div
      className={`group transition-opacity duration-500 ${isDimmed && !isLatest ? 'opacity-45' : 'opacity-100'}`}>
      
      {showRoundLabel &&
      <div className="flex items-center gap-3 mb-4 mt-2">
          <RoundBadge round={entry.round} isActive={isLatest} size="md" />
          <div className="flex-1 h-px bg-debate-border" />
        </div>
      }

      <div
        className={`
          flex gap-3 py-2.5 px-3 rounded-lg transition-all duration-300 relative
          ${isLatest && isSpeaking ? 'bg-debate-primary/[0.07]' : isLatest ? 'bg-debate-primary/[0.04]' : ''}
        `}>
        
        {/* Active speaker left accent bar */}
        {isLatest && isSpeaking &&
        <div
          className={`absolute left-0 top-1 bottom-1 w-[2px] rounded-full ${entry.speakerIndex === 0 ? 'bg-debate-primary' : 'bg-purple-400'}`} />

        }

        {/* Speaker indicator */}
        <div className="flex-shrink-0 pt-1">
          <div
            className={`
              w-2 h-2 rounded-full mt-1.5 transition-all duration-300
              ${entry.speakerIndex === 0 ? 'bg-debate-primary' : 'bg-purple-400'}
              ${isSpeaking && isLatest ? 'scale-125 ring-2 ring-current/20' : ''}
            `} />
          
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-baseline gap-2 mb-1">
            <span
              className={`text-xs font-semibold transition-colors duration-300 ${entry.speakerIndex === 0 ? 'text-debate-primary' : 'text-purple-400'}`}>
              
              {entry.speaker}
            </span>
            {isLatest && isSpeaking &&
            <span
              className={`
                inline-flex items-center gap-1 text-[9px] font-bold uppercase tracking-wider
                ${entry.speakerIndex === 0 ? 'text-debate-primary/70' : 'text-purple-400/70'}
              `}>
              
                <span className="w-1 h-1 rounded-full bg-current animate-pulse" />
                speaking
              </span>
            }
            <span className="text-[10px] text-debate-text-secondary font-mono ml-auto">
              {entry.timestamp}
            </span>
          </div>
          <p className="text-sm text-debate-text-primary/90 leading-relaxed">
            {renderHighlightedText(entry.text, entry.highlights)}
          </p>
        </div>
      </div>
    </div>);

}
export type { TranscriptEntry, TranscriptHighlight };