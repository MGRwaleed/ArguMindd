import React, { useEffect, useRef } from 'react';
import { TranscriptBlock } from './TranscriptBlock';
import { ScrollTextIcon } from 'lucide-react';
import type { TranscriptEntry } from './TranscriptBlock';
interface TranscriptPanelProps {
  entries: TranscriptEntry[];
  currentRound: number;
  activeSpeaker?: number;
}
export function TranscriptPanel({
  entries,
  currentRound,
  activeSpeaker
}: TranscriptPanelProps) {
  const scrollRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [entries.length]);
  // Group entries by round
  const roundGroups: Record<number, TranscriptEntry[]> = {};
  entries.forEach((entry) => {
    if (!roundGroups[entry.round]) roundGroups[entry.round] = [];
    roundGroups[entry.round].push(entry);
  });
  const sortedRounds = Object.keys(roundGroups).
  map(Number).
  sort((a, b) => a - b);
  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="px-5 py-4 border-b border-debate-border flex items-center justify-between flex-shrink-0">
        <div className="flex items-center gap-2">
          <ScrollTextIcon className="w-4 h-4 text-debate-primary" />
          <h2 className="text-xs font-semibold uppercase tracking-wider text-debate-text-secondary">
            Live Transcript
          </h2>
        </div>
        <div className="flex items-center gap-3">
          {activeSpeaker !== undefined &&
          <span
            className={`
              inline-flex items-center gap-1.5 text-[10px] font-semibold
              ${activeSpeaker === 0 ? 'text-debate-primary' : 'text-purple-400'}
            `}>
            
              <span className="w-1.5 h-1.5 rounded-full bg-current animate-pulse" />
              Speaker {activeSpeaker + 1} active
            </span>
          }
          <span className="text-[10px] text-debate-text-secondary font-mono">
            {entries.length} entries
          </span>
        </div>
      </div>

      {/* Transcript content */}
      <div
        ref={scrollRef}
        className="flex-1 overflow-y-auto px-5 py-4 space-y-1">
        
        {sortedRounds.map((round) => {
          const roundEntries = roundGroups[round];
          return (
            <div key={round}>
              {roundEntries.map((entry, idx) =>
              <TranscriptBlock
                key={entry.id}
                entry={entry}
                showRoundLabel={idx === 0}
                isLatest={
                round === currentRound && idx === roundEntries.length - 1
                }
                activeSpeaker={activeSpeaker} />

              )}
            </div>);

        })}

        {entries.length === 0 &&
        <div className="flex items-center justify-center h-full text-debate-text-secondary text-sm">
            Waiting for speakers...
          </div>
        }
      </div>

      {/* Auto-scroll indicator */}
      <div className="px-5 py-2.5 border-t border-debate-border flex-shrink-0">
        <div className="flex items-center gap-2">
          <div className="w-1.5 h-1.5 rounded-full bg-debate-primary animate-pulse" />
          <span className="text-[10px] text-debate-text-secondary">
            Auto-scrolling to latest
          </span>
        </div>
      </div>
    </div>);

}