import React from 'react';
import { MicIcon, MicOffIcon } from 'lucide-react';
interface SpeakerCardProps {
  name: string;
  role: string;
  avatar: string;
  isActive: boolean;
  speakerIndex: number;
}
export function SpeakerCard({
  name,
  role,
  avatar,
  isActive,
  speakerIndex
}: SpeakerCardProps) {
  return (
    <div
      className={`
        relative flex items-center gap-3.5 p-4 rounded-xl border transition-all duration-500
        ${isActive ? 'bg-debate-primary/[0.06] border-debate-primary/40 animate-border-glow' : 'bg-debate-surface border-debate-border hover:border-debate-border-light'}
      `}>
      
      {/* Active indicator line */}
      {isActive &&
      <div className="absolute left-0 top-3 bottom-3 w-[3px] rounded-full bg-debate-primary" />
      }

      {/* Avatar */}
      <div className="relative flex-shrink-0">
        <div
          className={`
            w-11 h-11 rounded-full flex items-center justify-center text-sm font-bold
            ${speakerIndex === 0 ? 'bg-debate-primary/15 text-debate-primary' : 'bg-purple-500/15 text-purple-400'}
          `}>
          
          {avatar}
        </div>
        {isActive &&
        <div className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-green-500 rounded-full border-2 border-debate-surface" />
        }
      </div>

      {/* Info */}
      <div className="flex-1 min-w-0">
        <p className="text-sm font-semibold text-debate-text-primary truncate">
          {name}
        </p>
        <p className="text-xs text-debate-text-secondary mt-0.5">{role}</p>
      </div>

      {/* Mic indicator */}
      <div
        className={`
          flex-shrink-0 w-8 h-8 rounded-lg flex items-center justify-center transition-colors duration-300
          ${isActive ? 'bg-debate-primary/15 text-debate-primary' : 'bg-debate-surface-light text-debate-text-secondary'}
        `}>
        
        {isActive ?
        <MicIcon className="w-4 h-4" /> :

        <MicOffIcon className="w-4 h-4" />
        }
      </div>
    </div>);

}