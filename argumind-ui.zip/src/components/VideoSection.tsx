import React from 'react';
import { VideoCard } from './VideoCard';
import type { Speaker } from './DebatePanel';
interface VideoSectionProps {
  speakers: [Speaker, Speaker];
  activeSpeaker: number;
  speaker1Score: number;
  speaker2Score: number;
}
export function VideoSection({
  speakers,
  activeSpeaker,
  speaker1Score,
  speaker2Score
}: VideoSectionProps) {
  return (
    <div className="flex-shrink-0 border-b border-debate-border bg-debate-bg">
      <div className="px-4 py-3">
        {/* Section label */}
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
            <span className="text-[10px] font-semibold uppercase tracking-wider text-debate-text-secondary">
              Live Feed
            </span>
          </div>
          <span className="text-[10px] text-debate-text-secondary/60 font-mono">
            HD • 30fps
          </span>
        </div>

        {/* Two video cards side by side */}
        <div className="flex gap-3">
          <VideoCard
            name={speakers[0].name}
            role={speakers[0].role}
            avatar={speakers[0].avatar}
            speakerIndex={0}
            isActive={activeSpeaker === 0}
            score={speaker1Score} />
          
          <VideoCard
            name={speakers[1].name}
            role={speakers[1].role}
            avatar={speakers[1].avatar}
            speakerIndex={1}
            isActive={activeSpeaker === 1}
            score={speaker2Score} />
          
        </div>
      </div>
    </div>);

}