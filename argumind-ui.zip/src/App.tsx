import React, { useEffect, useState, Component } from 'react';
import { DebatePanel } from './components/DebatePanel';
import { TranscriptPanel } from './components/TranscriptPanel';
import { FactCheckPanel } from './components/FactCheckPanel';
import { DebateSummary } from './components/DebateSummary';
import { VideoSection } from './components/VideoSection';
import type { Speaker } from './components/DebatePanel';
import type { TranscriptEntry } from './components/TranscriptBlock';
import type { FactCheck } from './components/FactCheckPanel';
import type { RoundScore } from './components/ScoreCard';
import type { SummaryData } from './components/DebateSummary';
// ─── Mock Data ───────────────────────────────────────────────
const speakers: [Speaker, Speaker] = [
{
  name: 'Dr. Sarah Chen',
  role: 'AI Ethics Researcher',
  avatar: 'SC'
},
{
  name: 'Prof. James Miller',
  role: 'Technology Policy Advisor',
  avatar: 'JM'
}];

const mockTranscript: TranscriptEntry[] = [
{
  id: 't1',
  speaker: 'Dr. Sarah Chen',
  speakerIndex: 0,
  text: 'Artificial intelligence regulation must prioritize transparency. Studies from MIT show that 78% of AI systems deployed in healthcare lack adequate explainability measures.',
  timestamp: '00:15',
  round: 1,
  highlights: [
  {
    type: 'keyword',
    start: 45,
    end: 57
  },
  {
    type: 'keyword',
    start: 79,
    end: 82
  }]

},
{
  id: 't2',
  speaker: 'Prof. James Miller',
  speakerIndex: 1,
  text: 'While transparency is important, over-regulation stifles innovation. The EU AI Act has already caused a 30% decline in AI startup funding across Europe.',
  timestamp: '00:42',
  round: 1,
  highlights: [
  {
    type: 'keyword',
    start: 55,
    end: 65
  },
  {
    type: 'claim-false',
    start: 86,
    end: 150
  }]

},
{
  id: 't3',
  speaker: 'Dr. Sarah Chen',
  speakerIndex: 0,
  text: 'That funding statistic is misleading. The decline was primarily due to broader market corrections, not regulation. In fact, regulated AI sectors saw increased institutional investment.',
  timestamp: '01:08',
  round: 1,
  highlights: [
  {
    type: 'keyword',
    start: 100,
    end: 110
  }]

},
{
  id: 't4',
  speaker: 'Prof. James Miller',
  speakerIndex: 1,
  text: 'Fair point on the market context. However, compliance costs for small AI companies have risen by 45% since 2023, creating barriers to entry that favor large corporations.',
  timestamp: '01:35',
  round: 1,
  highlights: [
  {
    type: 'keyword',
    start: 50,
    end: 67
  }]

},
{
  id: 't5',
  speaker: 'Dr. Sarah Chen',
  speakerIndex: 0,
  text: 'Moving to safety frameworks — the NIST AI Risk Management Framework provides a balanced approach. It allows for sector-specific implementation while maintaining core safety standards.',
  timestamp: '02:10',
  round: 2,
  highlights: [
  {
    type: 'keyword',
    start: 30,
    end: 68
  }]

},
{
  id: 't6',
  speaker: 'Prof. James Miller',
  speakerIndex: 1,
  text: 'The NIST framework is voluntary, which is precisely why it works. Mandatory frameworks like the proposed US AI Bill would require companies to disclose proprietary training data, undermining competitive advantage.',
  timestamp: '02:38',
  round: 2,
  highlights: [
  {
    type: 'keyword',
    start: 80,
    end: 98
  },
  {
    type: 'claim-false',
    start: 119,
    end: 207
  }]

},
{
  id: 't7',
  speaker: 'Dr. Sarah Chen',
  speakerIndex: 0,
  text: 'That characterization of the US AI Bill is inaccurate. The bill requires disclosure of training data categories, not the actual proprietary datasets. This distinction is critical.',
  timestamp: '03:05',
  round: 2
},
{
  id: 't8',
  speaker: 'Prof. James Miller',
  speakerIndex: 1,
  text: 'I stand corrected on the specifics. But the broader concern remains — even category disclosure can reveal strategic directions. We need sandboxed testing environments instead of blanket disclosure rules.',
  timestamp: '03:30',
  round: 2,
  highlights: [
  {
    type: 'keyword',
    start: 120,
    end: 150
  }]

},
{
  id: 't9',
  speaker: 'Dr. Sarah Chen',
  speakerIndex: 0,
  text: 'For autonomous systems, we need mandatory human oversight loops. The Boeing 737 MAX incidents demonstrated what happens when automated systems operate without adequate human intervention protocols.',
  timestamp: '04:15',
  round: 3,
  highlights: [
  {
    type: 'keyword',
    start: 35,
    end: 57
  },
  {
    type: 'keyword',
    start: 63,
    end: 80
  }]

},
{
  id: 't10',
  speaker: 'Prof. James Miller',
  speakerIndex: 1,
  text: 'The Boeing comparison is flawed — aviation software and AI models operate on fundamentally different paradigms. Self-driving cars have reduced accident rates by 60% in controlled deployments.',
  timestamp: '04:42',
  round: 3,
  highlights: [
  {
    type: 'claim-false',
    start: 115,
    end: 186
  }]

},
{
  id: 't11',
  speaker: 'Dr. Sarah Chen',
  speakerIndex: 0,
  text: 'The 60% figure is cherry-picked from optimal conditions. Real-world data from Waymo and Cruise shows a more nuanced picture — roughly 20-35% reduction depending on environment and conditions.',
  timestamp: '05:10',
  round: 3
},
{
  id: 't12',
  speaker: 'Prof. James Miller',
  speakerIndex: 1,
  text: 'Acknowledged — the controlled deployment figure was overstated. But even a 20% reduction represents thousands of lives saved annually. The question is whether regulation accelerates or decelerates that progress.',
  timestamp: '05:38',
  round: 3,
  highlights: [
  {
    type: 'keyword',
    start: 75,
    end: 100
  }]

}];

const mockFactChecks: FactCheck[] = [
{
  id: 'fc1',
  round: 1,
  claim: '78% of AI systems in healthcare lack adequate explainability',
  verdict: 'true',
  evidence:
  'A 2024 MIT study found that approximately 76-80% of deployed clinical AI systems lacked sufficient explainability documentation, consistent with this claim.',
  source: 'MIT AI Lab Report, 2024',
  speaker: 'Dr. Sarah Chen',
  speakerIndex: 0
},
{
  id: 'fc2',
  round: 1,
  claim: 'EU AI Act caused 30% decline in AI startup funding across Europe',
  verdict: 'false',
  evidence:
  'While EU AI startup funding did decline, the drop was approximately 12-15% and was largely attributed to global market corrections, not solely the AI Act.',
  source: 'Crunchbase European AI Report, 2024',
  speaker: 'Prof. James Miller',
  speakerIndex: 1
},
{
  id: 'fc3',
  round: 1,
  claim: 'Compliance costs for small AI companies rose by 45% since 2023',
  verdict: 'uncertain',
  evidence:
  'Various reports cite different figures. Some surveys show 30-50% increases in compliance-related spending, but methodology varies significantly across studies.',
  speaker: 'Prof. James Miller',
  speakerIndex: 1
},
{
  id: 'fc4',
  round: 2,
  claim:
  'US AI Bill would require companies to disclose proprietary training data',
  verdict: 'false',
  evidence:
  'The proposed legislation requires disclosure of training data categories and sources, not the actual proprietary datasets themselves.',
  source: 'US AI Accountability Act Draft, 2024',
  speaker: 'Prof. James Miller',
  speakerIndex: 1
},
{
  id: 'fc5',
  round: 2,
  claim: 'NIST AI Risk Management Framework provides balanced approach',
  verdict: 'true',
  evidence:
  'The NIST AI RMF is widely regarded by industry and academia as a balanced, flexible framework that accommodates sector-specific needs.',
  source: 'NIST AI 100-1, 2023',
  speaker: 'Dr. Sarah Chen',
  speakerIndex: 0
},
{
  id: 'fc6',
  round: 3,
  claim:
  'Self-driving cars reduced accident rates by 60% in controlled deployments',
  verdict: 'false',
  evidence:
  'Waymo and Cruise data from controlled deployments show 20-35% reduction in accident rates depending on conditions, not 60%.',
  source: 'NHTSA Autonomous Vehicle Report, 2024',
  speaker: 'Prof. James Miller',
  speakerIndex: 1
},
{
  id: 'fc7',
  round: 3,
  claim:
  'Boeing 737 MAX incidents relate to automated systems without human oversight',
  verdict: 'true',
  evidence:
  'The MCAS system on the 737 MAX operated with insufficient human override capabilities, contributing to two fatal crashes. This is a well-documented case of automation failure.',
  source: 'FAA Investigation Report',
  speaker: 'Dr. Sarah Chen',
  speakerIndex: 0
}];

const mockRoundScores: RoundScore[] = [
{
  round: 1,
  speaker1: 8,
  speaker2: 6
},
{
  round: 2,
  speaker1: 7,
  speaker2: 7
},
{
  round: 3,
  speaker1: 8,
  speaker2: 7
}];

const mockSummary: SummaryData = {
  overallVerdict:
  'Dr. Sarah Chen demonstrated stronger factual accuracy and more nuanced argumentation throughout the debate. Prof. James Miller raised valid concerns about innovation but relied on several overstated statistics that were successfully challenged.',
  keyArguments: [
  'AI regulation must balance transparency with innovation — both speakers agreed on this fundamental tension',
  "The EU AI Act's impact on startup funding was contested, with evidence supporting a more moderate decline than initially claimed",
  'Voluntary vs. mandatory frameworks emerged as the central policy disagreement',
  'Autonomous systems safety data requires careful contextualization — controlled vs. real-world conditions matter significantly'],

  speaker1Strengths: [
  'Consistently accurate factual claims backed by verifiable sources',
  "Effective at correcting opponent's mischaracterizations with specific evidence",
  'Strong use of analogies (Boeing 737 MAX) to illustrate systemic risks'],

  speaker1Weaknesses: [
  'Could have addressed the innovation cost concern more directly',
  'Limited discussion of practical implementation challenges'],

  speaker2Strengths: [
  'Raised legitimate concerns about compliance costs and barriers to entry',
  'Willingness to acknowledge corrections showed intellectual honesty',
  'Strong framing of the innovation vs. regulation tradeoff'],

  speaker2Weaknesses: [
  'Multiple factual claims were overstated or inaccurate (30% funding decline, 60% accident reduction)',
  "Mischaracterized the US AI Bill's disclosure requirements",
  'Relied too heavily on specific statistics without proper context']

};
// ─── App Component ───────────────────────────────────────────
export function App() {
  const [currentRound, setCurrentRound] = useState(2);
  const [activeSpeaker, setActiveSpeaker] = useState(0);
  const [isSummaryOpen, setIsSummaryOpen] = useState(false);
  const [visibleEntries, setVisibleEntries] = useState<TranscriptEntry[]>([]);
  // Simulate live transcript feed
  useEffect(() => {
    const entriesUpToRound = mockTranscript.filter(
      (e) => e.round <= currentRound
    );
    let index = 0;
    // Show entries with staggered timing for "live" feel
    const showNext = () => {
      if (index < entriesUpToRound.length) {
        setVisibleEntries((prev) => {
          if (prev.find((e) => e.id === entriesUpToRound[index].id)) {
            index++;
            return prev;
          }
          return [...prev, entriesUpToRound[index++]];
        });
      }
    };
    // Show first batch quickly
    const initialBatch = entriesUpToRound.slice(0, entriesUpToRound.length - 1);
    setVisibleEntries(initialBatch);
    index = initialBatch.length;
    // Then add the last one with a delay for effect
    const timer = setTimeout(showNext, 800);
    return () => clearTimeout(timer);
  }, [currentRound]);
  // Toggle active speaker periodically
  useEffect(() => {
    const interval = setInterval(() => {
      setActiveSpeaker((prev) => prev === 0 ? 1 : 0);
    }, 5000);
    return () => clearInterval(interval);
  }, []);
  const factChecksUpToRound = mockFactChecks.filter(
    (fc) => fc.round <= currentRound
  );
  const scoresUpToRound = mockRoundScores.filter(
    (rs) => rs.round <= currentRound
  );
  const speaker1Total = scoresUpToRound.reduce((sum, r) => sum + r.speaker1, 0);
  const speaker2Total = scoresUpToRound.reduce((sum, r) => sum + r.speaker2, 0);
  const winnerId =
  scoresUpToRound.length > 0 ?
  speaker1Total > speaker2Total ?
  0 :
  speaker1Total === speaker2Total ?
  undefined :
  1 :
  undefined;
  return (
    <div className="w-full h-screen bg-debate-bg flex flex-col overflow-hidden">
      {/* Top bar */}
      <header className="flex-shrink-0 h-12 px-5 flex items-center justify-between border-b border-debate-border bg-debate-surface/50">
        <div className="flex items-center gap-3">
          <div className="w-7 h-7 rounded-lg bg-debate-primary/15 flex items-center justify-center">
            <svg
              width="14"
              height="14"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="text-debate-primary">
              
              <path d="M12 2L2 7l10 5 10-5-10-5z" />
              <path d="M2 17l10 5 10-5" />
              <path d="M2 12l10 5 10-5" />
            </svg>
          </div>
          <span className="text-sm font-semibold text-debate-text-primary tracking-tight">
            AI Debate Judge
          </span>
          <span className="text-[10px] text-debate-text-secondary font-medium px-2 py-0.5 rounded bg-debate-surface border border-debate-border">
            v2.0
          </span>
        </div>

        <div className="flex items-center gap-3">
          {/* Round selector */}
          <div className="flex items-center gap-1 bg-debate-surface rounded-lg border border-debate-border p-0.5">
            {[1, 2, 3].map((r) =>
            <button
              key={r}
              onClick={() => setCurrentRound(r)}
              className={`
                  px-3 py-1 rounded-md text-xs font-semibold transition-all duration-200 cursor-pointer
                  ${currentRound === r ? 'bg-debate-primary/15 text-debate-primary' : 'text-debate-text-secondary hover:text-debate-text-primary'}
                `}>
              
                R{r}
              </button>
            )}
          </div>

          <div className="w-px h-5 bg-debate-border" />

          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full bg-emerald-400" />
            <span className="text-[10px] text-debate-text-secondary font-medium">
              Live
            </span>
          </div>
        </div>
      </header>

      {/* Main layout */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Panel — Debate / Speakers */}
        <aside className="w-72 flex-shrink-0 border-r border-debate-border bg-debate-surface/30 overflow-y-auto">
          <DebatePanel
            speakers={speakers}
            activeSpeaker={activeSpeaker}
            currentRound={currentRound}
            totalRounds={3}
            timerSeconds={
            currentRound === 2 ? 45 : currentRound === 3 ? 120 : 0
            }
            isTimerRunning={currentRound === 2}
            topic="Should AI development be subject to mandatory government regulation?" />
          
        </aside>

        {/* Right content area — Video on top, Transcript + Fact-check below */}
        <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
          {/* Video Section */}
          <VideoSection
            speakers={speakers}
            activeSpeaker={activeSpeaker}
            speaker1Score={speaker1Total}
            speaker2Score={speaker2Total} />
          

          {/* Lower panels — Transcript + Fact-check side by side */}
          <div className="flex-1 flex overflow-hidden">
            {/* Center Panel — Transcript */}
            <main className="flex-1 min-w-0 border-r border-debate-border bg-debate-bg">
              <TranscriptPanel
                entries={visibleEntries}
                currentRound={currentRound}
                activeSpeaker={activeSpeaker} />
              
            </main>

            {/* Right Panel — Fact-Check + Score */}
            <aside className="w-80 flex-shrink-0 bg-debate-surface/30 overflow-hidden">
              <FactCheckPanel
                factChecks={factChecksUpToRound}
                roundScores={scoresUpToRound}
                speaker1Name={speakers[0].name}
                speaker2Name={speakers[1].name}
                winnerId={winnerId}
                currentRound={currentRound}
                onOpenSummary={() => setIsSummaryOpen(true)} />
              
            </aside>
          </div>
        </div>
      </div>

      {/* Summary Modal */}
      <DebateSummary
        isOpen={isSummaryOpen}
        onClose={() => setIsSummaryOpen(false)}
        summary={mockSummary}
        speaker1Name={speakers[0].name}
        speaker2Name={speakers[1].name} />
      
    </div>);

}